
//--->post date/time - start
$(document).on('focus', '.PostDttm', function(event) 
{
	event.preventDefault();	
	$('.PostDttm').datetimepicker();
});
 


//--->post date/time - start
 