$(document).ready(function()
{
    
    var get_comment_container = $('.comment_container')
    if(get_comment_container.length > 0)
    {
        get_comment_container.remove();
    }

})  