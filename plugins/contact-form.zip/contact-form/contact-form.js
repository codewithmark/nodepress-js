var user_contact_form = function(obj)
{
    var str1 = '<div class="center-block container_contact_form"><div class="contact_alert"></div><div class=" contact_form_container"><br style="clear: both;"/><h3 style="margin-bottom: 25px; text-align: center;"></h3><div class="input-group"> <span class="input-group-addon">Name</span> <input type="text" class="form-control user_name contact_frm"/></div> <br><div class="input-group"> <span class="input-group-addon">Email</span> <input type="email" class="form-control user_email contact_frm"/></div> <br><div class="input-group"> <span class="input-group-addon">Subject</span> <input type="email" class="form-control user_subject contact_frm"/></div><br><div class="form-group"><p>Message</p><textarea class="form-control user_msg contact_frm" type="textarea" rows="7" ></textarea></div><button type="button" class="btn btn-primary pull-right btn_contact">Submit Form</button></div><div class="panel panel-default contact_post_msg" style="display:none"><div class="panel-body "></div></div><div class=""></div></div><br><br>';

    $(document).find('.contact_me').html(str1);

    $(document).find('.contact_post_msg').find('.panel-body').html(obj.post_contact_msg);

    $(document).find('.btn_contact').attr('ajax_url', obj.ajax_url);

}

$(document).ready(function()
{


    //load functions
    var get_contact_form = $(document).find('.plugin_contact_form_code_with_mark');

    if(get_contact_form.length > 0)
    {         
        get_contact_form.after('<div class="contact_me"> loading...</div>');
        get_contact_form.remove();


        var get_contact_frm = JSON.parse( np_ls_get('ls_contact_form') );
      
        if(np_size(get_contact_frm) > 0 && np_check_expire_timer(get_contact_frm.code_expire_sec) > 0  )
        { 
            user_contact_form(get_contact_frm);         
            return false;
        }
         
        //get option values
        var ajax = np_ajax_option('contact_form')    
         
        ajax.done(function(d1) 
        { 
            //console.log(d1);

            if(d1.status == 'success') 
            {
                var option_data;

                if(typeof(d1.option_value) == 'string')
                {
                    option_data = JSON.parse(d1.option_value);
                }
                else
                {
                    option_data =  d1.option_value;
                }

                var ajax_url  =  option_data.ajax_url;
                var post_contact_msg = option_data.post_contact_msg; 


                var date_expire = np_get_expire_timer({min:5});

                //add to localstorage
                var obj = 
                {
                    ajax_url:ajax_url,
                    post_contact_msg:post_contact_msg,
                    code_expire_sec:date_expire.unix,
                    code_expire_iso: date_expire.iso,
                }
                np_ls_add('ls_contact_form', JSON.stringify(obj) );   

                user_contact_form(obj)

            }
     
        })
    }

    $(document).on('click', '.btn_contact', function(event) 
    {    
        event.preventDefault();

        //To clear all old alerts
        bs.ClearError();

        var ele = $(this).closest('.container_contact_form');

        //Get the field value
        var user_name       = ele.find('.user_name');
        var user_email      = ele.find('.user_email');
        var user_subject    = ele.find('.user_subject');
        var user_msg        = ele.find('.user_msg'); 

        // Validate field
        if(frm.IsEmpty(user_name.val()))
        {
            //Show alert
            bs.ShowError ("Please enter text",user_name);
        }
        else if(frm.IsEmpty(user_email.val()))
        {
            //Show alert
            bs.ShowError ("Please enter text",user_email);
        }
        else if(frm.IsEmail(user_email.val()))
        {
            //Show alert
            bs.ShowError ("Invaid Email ",user_email)
        }
        else if(frm.IsEmpty(user_subject.val()))
        {
            //Show alert
            bs.ShowError ("Please enter text",user_subject);
        }
        else if(frm.IsEmpty(user_msg.val()))
        {
            //Show alert
            bs.ShowError ("Please enter text",user_msg);
        }
        else            
        {
            var ref_url = location.protocol + '//' + location.host+ '/';
            var ref_url =  window.location.href; 
            var DataString = 
            {
                user_name:user_name.val(),
                user_email:user_email.val(),
                user_subject:user_subject.val(),
                user_msg:user_msg.val(),
                ref_url:ref_url,
            };
            
            var ajax_url =  $(document).find('.btn_contact').attr('ajax_url');            

            $(document).find('.contact_post_msg').show();
            $(document).find('.contact_form_container').hide();
       
            np_sm_ajax({url:ajax_url,type:'post',data:DataString},function(data)
            {
                //console.log(data);
            })
        }
    });

}) 
 