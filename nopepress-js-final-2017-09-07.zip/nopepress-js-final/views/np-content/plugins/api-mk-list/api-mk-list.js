var List_Signup_Form = function (object_data)
{   
    //Get object Arr
    var obj = object_data 

    var panel_classes = ['panel-default','panel-primary','panel-success','panel-info','panel-warning','panel-danger'];

    var get_panel_class = obj.frm_class ? obj.frm_class : np_random_pick(panel_classes);
     
    var strDIV = ''
    +'<br><br>'
    +'<div class="list_form"  >'      
        +'<div class="list_form_alert"> </div>'

        +'<div class="panel '+get_panel_class+'"  >'             
            +'<div class="panel-heading '+get_panel_class+' text-capitalize" style="font-size: large;" >'+ obj.frm_header + '</div>'
            +'<div style="padding:10px;"> '

                +'<div class="form-group">'
                    +'<label>Name</label>'
                    +'<input type="text" class="form-control SignupForm UserName " value="">'
                +'</div>'

                +'<div class="form-group">'
                    +'<label>Email</label>'
                    +'<input type="email" class="form-control SignupForm UserEmail " value="">'
                +'</div>'

                    
                + '<button type="submit" class="btn btn-default btn_Signup" frm_id="'+obj.frm_id+'"  frm_cat="'+obj.frm_cat+'" >'+ obj.frm_btn_name + '</button>'
            +'</div>'
        +'</div>'
    +'</div>';
    return strDIV;
}


//variables
var ls_site_plugin_code = 'site_plugin_code';
var ls_site_list_forms  = 'site_list_forms';
var list_ajax_url       = 'https://apimk.com/list/';

var get_list_code_data = function () 
{ 
    var list_code = JSON.parse( np_ls_get(ls_site_plugin_code) );

    if(np_size(list_code) > 0 && np_check_expire_timer(list_code.code_expire_sec) > 0  )
    { 
        get_list_data(list_code);         
        return false;
    } 

    var ajax = np_ajax_option('api_mk_list_plugin');

    ajax.done(function(data) 
    { 
        //console.log(data);

        var get_status = data.status;

        if(get_status =='success')
        { 
            //add 5 minutes to expire timestamp
            var date_expire = np_get_expire_timer({min:5});

            //add to localstorage
            var obj = 
            {
                site_code:data.option_value,
                code_expire_sec:date_expire.unix,
                code_expire_iso: date_expire.iso,
            }
            np_ls_add(ls_site_plugin_code, JSON.stringify(obj) ); 

            get_list_data(obj);             
        }
    }); 
}

var get_list_data = function(list_code)
{ 
    var get_frm_data = JSON.parse( np_ls_get(ls_site_list_forms) );



    if(np_size(get_frm_data) > 0 && np_check_expire_timer(get_frm_data.code_expire_sec) > 0  )    
    {
        check_random_form(get_frm_data.frm_data);
        return false;
    }
    
  

    $.get(list_ajax_url+'cat/'+list_code.site_code+'/all', function(data) 
    {  
        try 
        {          
            var date_expire = np_get_expire_timer({min:5});

            //add to localstorage
            var obj = 
            {
                frm_data:data.rec_data,
                code_expire_sec:date_expire.unix,
                code_expire_iso: date_expire.iso,
            }            
            np_ls_add(ls_site_list_forms, JSON.stringify(obj) ); 
            
            check_random_form(data.rec_data);

            //in case cookies are disableds
            var object_data = JSON.stringify(data.rec_data);
            var div = '<div class="list_forms" style="display:none1;">'+object_data+'</div>';
            //$('body').append(div);           
        }
        catch(err) 
        {
            $(document).find('.random_newsletter').html('error api call');
            return false;
        }
        
    });
}

var check_random_form = function(list_code)
{    
    var random_list_container = $(document).find('.np_single_post');  

    if(random_list_container.length < 0)
    {
        //random_list_container.after('no form data')
        return false;
    }
   
    var exclude_list = [];
   
    $.each(list_code, function(index, ele)   
    {
        if(ele.frm_exclude == 'no')
        {
            exclude_list.push(ele);
        }
    });

    $.each(random_list_container, function(i, v) 
    {
        var ele = $(this);
        //clear dummy data
        //ele.html('loading');
        var sign_frm = np_random_pick(exclude_list); 
        //console.log(sign_frm)
         
        var object_data = List_Signup_Form(
        {            
            frm_header:sign_frm.frm_header, 
            frm_id: sign_frm.frm_id,
            frm_cat: sign_frm.frm_cat,
            frm_btn_name:sign_frm.frm_btn_name,      
        });

        ele.after('<div style="padding:20px;">'+object_data+'</div>');
    })
}



var get_newsletter_frm = function(id,cb)
{
    var list_code = ls.GetAllArr(ls_site_list_forms).frm_data;

    var frm_id_data = [];

    $.each(list_code, function(index, ele)   
    {
        if(ele.frm_id == id)
        {
            frm_id_data.push(ele);
        }
    })

    if(np_size(frm_id_data) < 1)
    {
        var d =''
        +'<div style="text-align: center;  ">'
            +'<i class="fa fa-frown-o" style="font-size:200px;"></i>'

            +'<div style="text-align: center;">'
                +'<span style="font-size:48px">Oh...No</span>'
            +'</div>'

            +'<br><br>'
            +'<p style="text-align: center;">'
                +'<span style="font-size:28px">Can\'t  Find Your Form....</span>'
            +'</p>'
            +'<br><br>'
        +'</div>'

        //in case if the localstore fails for some reason... 
        $.get(list_ajax_url+'frm/'+id , function(data) 
        { 
            //console.log(data)
            
            var sign_frm = data.rec_data;          
            var object_data = List_Signup_Form(
            {
                frm_class: 'panel-primary',
                frm_header:sign_frm.frm_header, 
                frm_id: sign_frm.frm_id,
                frm_cat: sign_frm.frm_cat,
                frm_btn_name:sign_frm.frm_btn_name,      
            });
            cb(object_data)
        })
    }
    else if(np_size(frm_id_data) > 0)
    {
        var sign_frm = frm_id_data[0];          
        var object_data = List_Signup_Form(
        {
            frm_class: 'panel-primary',
            frm_header:sign_frm.frm_header, 
            frm_id: sign_frm.frm_id,
            frm_cat: sign_frm.frm_cat,
            frm_btn_name:sign_frm.frm_btn_name,      
        });
        cb(object_data)
    }
}


$(document).ready(function() 
{
    get_list_code_data(); 

    $(document).on('click', '.btn_api_mk_frm', function(event) 
    {
        event.preventDefault();
        var frm_id = $(this).attr('frm_id') 
       
        if(np_size(frm_id) > 0)
        {
            get_newsletter_frm(frm_id, function(data)
            {
                var ModalTitle = ''
                var ModalBodyContent = data
                bs.Modal(ModalTitle,ModalBodyContent )
            })
        }
         
    });

    //--->signup form > start
    //var list_ajax_url = '/list/signup';

    $(document).on('keypress','.SignupForm', function(event) 
    { 
        var code = event.keyCode ? event.keyCode : event.which; 
        if (code == 13) 
        {
            var ele = $(this).closest('.list_form') 
            validate_signup (ele); 
        }
    });

    $(document).on('click', '.btn_Signup', function(event) 
    {
        event.preventDefault();
        var ele = $(this).closest('.list_form') 
        validate_signup (ele); 
    });


    var validate_signup = function(ele)
    {
        bs.ClearError();

        var user_name   = ele.find('.UserName');
        var user_email  = ele.find('.UserEmail');

        var frm_id      = ele.find('.btn_Signup').attr('frm_id');
        var frm_cat     = ele.find('.btn_Signup').attr('frm_cat');
        var frm_alert   = ele.find('.list_form_alert'); 
        
        // Validate field
        if(frm.IsEmpty(user_name.val() ))
        {
        //Show alert
            bs.ShowError ("Please enter name",user_name);
        }
        else if(frm.IsEmpty(user_email.val() ))
        {
        //Show alert
            bs.ShowError ("Please enter email",user_email);
        }
        else if(frm.IsEmail(user_email.val() ))
        {
        //Show alert
            bs.ShowError ("Invalid Email",user_email);
        }
        else
        {
            var d = bs.WaitingMsg("Please wait....Processing your request");

            frm_alert.html(d);
            //      

            var DataString =
            {
                frm_cat:frm_cat,
                frm_id:frm_id,
                user_name:_.escape(user_name.val()),
                user_email:user_email.val(),
            }

            var CallType = 'POST';
            var AjaxURL = list_ajax_url+'signup';
             
            var ajax = js.Ajax(CallType,AjaxURL,DataString)
            
            //error
            ajax.fail(function(xhr, ajaxOptions, thrownError)  
            { 
                //do your error handling here
                console.log(thrownError);
                console.log(xhr); 
            });

            //success
            ajax.done(function(data) 
            { 
                //do your success data processing here
                //console.log(data);

                var get_status = data.status;

                if(get_status =='success')
                {
                    ele.find('.panel').hide();

                    var get_code = data.code;

                    if(get_code == 'newuser' || get_code == 'pending')
                    {
                        var d1 = bs.AlertMsg(data.msg, "success");
                        frm_alert.html(d1);
                        ele.find('.form-control').attr('disabled','disabled');
                        ele.find('.btn_Signup').attr('disabled','disabled');
                    }
                    else if(get_code == 'redirect')
                    {
                        var d1 = bs.AlertMsg("click the button below", "warning");
                        d1 +='<br>';
                        d1 +='<a class="btn btn-primary btn-lg" href="'+data.url+'" target="_blank">'+data.frm_btn_name+'</a>';
                        d1 +='<br>';
                        frm_alert.html(d1);
                        return false; 
                    }
                    else if(get_code == 'dl')
                    {   
                        var DLURL = data.url;
                        var d1 = bs.AlertMsg("click the button to download", "warning");
                        d1 +='<br>';
                        d1 +='<a class="btn btn-primary btn-lg Btn_UserDL" download data-dl-link="'+DLURL+'"  >Download</a>';
                        d1 +='<br>';
                        frm_alert.html(d1);
                    }
                    else if(get_code == 'course')
                    {   
                        var d1 = bs.AlertMsg(data.msg, "warning");                       
                        frm_alert.html(d1);
                    }

                }
            })

        }
    }    
    //--->signup form > end


    //--->Hide dl link info - Start     
    $( document ).on( 'mouseover', 'a', function(e) 
    {     
      var GetDLLink = $(this).attr('data-dl-link');
      if(GetDLLink) 
      {         
        var id = Math.random().toString(36).substr(2);
        $(this).attr("href",id);
      }        
    });
    //--->Hide dl link info - End

    //--->Download Click Event - Start
    $( document ).on( 'click', '.Btn_UserDL', function(e) 
    {
        var d =$(this).attr('data-dl-link');
        if(d)
        {    
            //e.preventDefault();  
            $(this).attr({ href:d});
        } 
    });
    //--->Download Click Event - End 
});