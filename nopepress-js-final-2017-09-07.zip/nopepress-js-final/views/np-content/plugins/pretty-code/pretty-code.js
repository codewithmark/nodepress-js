$(document).ready(function()
{
    //load functions
    PrettyCode()


    var ajax = np_ajax_option('pretty_code')    
     
    ajax.done(function(data) 
    { 
        //console.log(data) 
 
    })


}) 
var PrettyCode = function () 
{
    /*
        this will load the code container from the page and add line numbers to it
    */
    $('code').each(function(i1, v1) 
    { 
        var get_pre_container = $(this).closest('pre');
        var get_pre_container_class = get_pre_container.attr('class');        
        var raw_code = $(this).html()
        var code_container = $(this).html().split('\n')
        var class_id  = Math.random().toString(36).substr(2, 5);

        var html = ''

        html+='<div class="table-responsive  "> '
            html+= '<pre class="'+get_pre_container_class+'" style="background:none!important;">'
            html+='<table class="table table-hover table-condensed" >'
            $.each(code_container, function(i2, v2) 
            {
                html+=''
                +'<tr >'
                    //Line number 
                    +'<td style="border-right-width:3px;border-right-style: solid;border-right-color: rgb(108, 226, 108);">' + (i2 + 1) + '</td> '
                    //code
                    +'<td style="    border-top: 1px solid #f0f0f0;">'+v2+'</td> '
                +'</tr>'                
            })          
            html+= '</table>'
            html+= '</pre>'     
        html+='</div>' 

        var arr = 
        [   
            {tab_name:'Code', tab_content:html},
            {tab_name:'Raw Code', tab_content: '<pre class="'+get_pre_container_class+'" >'+raw_code +'</pre>'}, 
        ]
        get_pre_container.after( BS_Tabs(arr) );
        

        //remove the original container
        get_pre_container.remove()

    });
}


var BS_Tabs = function (ObjArr)
{   
    /*
        Will create a Bootstrap tab screen

        //example tab data array
        var arr = [ 
            {tab_name:'tab 1', tab_content: "this is my tab 1 contain is"},
            {tab_name:'tab 2', tab_content: "this is my tab 2 "},
        ]
    */
    //Get object Arr
    var arr = ObjArr; 

    //--->get tab name - start
    var id  = Math.random().toString(36).substr(2, 5);
    var strTabName = '';
    strTabName +='<ul class="nav nav-tabs" role="tablist">';
    arr.forEach( function(element, index) 
    {
        //var tab_id =  (element.tab_name).replace(/[^\w]+/g, '-') 
        var tab_id =  (element.tab_name).replace(/[^\w]+/g, '-') +'-id-'+id
        var tab_name = element.tab_name
        if(index <1)
        {
            strTabName +='<li role="presentation" class="active"><a href="#'+tab_id+'"  role="tab" data-toggle="tab">'+tab_name+'</a></li>'
        }
        else
        {
            strTabName +='<li role="presentation"><a href="#'+tab_id+'"  role="tab" data-toggle="tab">'+tab_name+'</a></li>'
        }
         
    });
    strTabName +='</ul>';
    //--->get tab name - end

    //--->get tab content - start
    var strTabContent = '';
    strTabContent +='<div class="tab-content" style="padding:10px;">';
    arr.forEach( function(element, index) 
    {
        var tab_id = (element.tab_name).replace(/[^\w]+/g, '-') +'-id-'+id
        var tab_content = element.tab_content
        if(index <1)
        {
            strTabContent +='<div role="tabpanel" class="tab-pane active '+tab_id+'" id="'+tab_id+'">'+tab_content+'</div>'
        }
        else
        {
            strTabContent +='<div role="tabpanel" class="tab-pane '+tab_id+'" id="'+tab_id+'">'+tab_content+'</div>'
        }
         
    });
    strTabContent +=' </div>';
    //--->get tab content - end

    var strTabDiv = ''
    +'<div class="panel panel-default"  >'    
        + strTabName
        + strTabContent    
    + '</div>'
    //console.log(strTabDiv)
    return strTabDiv;
    
}