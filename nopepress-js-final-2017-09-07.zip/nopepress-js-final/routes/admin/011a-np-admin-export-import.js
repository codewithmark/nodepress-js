/*
	Export -> CRUD 

	C = Create
	R = Read/Get
	U = Update 
	D = Delete
*/




//--->get data - start
app.get('/np-admin/export', function(req, res, next) 
{ 
	//If config file doesn't exist
	if(!func_db.db_config_file_check() ) return res.redirect( func.DomainURL(req).url + '/np-config' ) 
 

	//check to see if logged in and has valid admin token
	func_db.admin_token_check(req).then(function(d1)
	{
		var site_url = func.DomainURL(req).cur_path 

		var Status = d1.status;
		if(Status=="error")
		{
			//error with admin token
			res.json(d1) 			
			return false  
		}

		//all good to go
		func.log('GET-> '+ site_url ) 

		var datasend 	= req.query.datasend


		var np_comments = new Promise(function(resolve, reject) 
		{
			npdb.collection('np_comments')
			.find({}, {_id:false,})			 
			.toArray(function (err,  data)
			{
				if(data) 
				{
					resolve( data);
				}			
			})
		})

		var np_options = new Promise(function(resolve, reject) 
		{
			npdb.collection('np_options')
			.find({}, {_id:false,})			 
			.toArray(function (err,  data)
			{
				if(data) 
				{
					resolve( data);
				}			
			})
		})

		var np_posts = new Promise(function(resolve, reject) 
		{
			npdb.collection('np_posts')
			.find({}, {_id:false,})
			.toArray(function (err,  data)
			{
				if(data) 
				{
					resolve( data);
				}			
			})
		})


		var np_terms = new Promise(function(resolve, reject) 
		{
			npdb.collection('np_terms')
			.find({}, {_id:false,})
			.toArray(function (err,  data)
			{
				if(data) 
				{
					resolve( data);
				}			
			})
		})

		var np_users = new Promise(function(resolve, reject) 
		{
			npdb.collection('np_users')
			.find({}, {_id:false,})
			.toArray(function (err,  data)
			{
				if(data) 
				{
					resolve( data);
				}			
			})
		})

		Promise.all([np_comments,np_options,np_posts,np_terms,np_users]).then(function(results) 
		{
			var np_comments = results[0]
			var np_options 	= results[1]
			var np_posts 	= results[2]
			var np_terms 	= results[3]
			var np_users 	= results[4]
			res.json( 
			{
				status:'success', msg:'export data',
				np_comments:np_comments,
				np_options:np_options,
				np_posts:np_posts,
				np_terms:np_terms,
				np_users:np_users, 
			}) 
		})

	})
 

});
//--->get data - end


//--->post data - start
app.post('/np-admin/import', function(req, res, next) 
{ 
	//If config file doesn't exist
	if(!func_db.db_config_file_check() ) return res.redirect( func.DomainURL(req).url + '/np-config' ) 
 

	//check to see if logged in and has valid admin token
	func_db.admin_token_check(req).then(function(d1)
	{
		var site_url = func.DomainURL(req).cur_path 

		var Status = d1.status;
		if(Status=="error")
		{
			//error with admin token
			res.json(d1) 			
			return false  
		}

		//all good to go
		func.log('POST-> '+ site_url ) 

		
		var datasend 		= req.body.datasend
		var import_type 	= req.body.import_type
		var np_users 		= req.body.np_users
		var np_options 		= req.body.np_options
		var np_posts 		= req.body.np_posts
		var np_terms 		= req.body.np_terms
		var np_comments 	= req.body.np_comments

		//delay for 1 second
		var delayMillis = 1000 

		if(_.size(import_type) < 1)
		{
			res.json({status:'error', msg:'missing import_type',})
			return false
		}

		if(_.size(import_type) > 0 )
		{
			

			if(import_type =='delete')
			{
				

				//console.log('import_type ', import_type)

				//--->delete all old data > start
				//np_users
				if(_.size(np_users) > 0 )
				{
					//delete 
					npdb.collection('np_users').deleteMany({})
					 
				}

				//np_options
				if(_.size(np_options) > 0 )
				{
					//delete 
					npdb.collection('np_options').deleteMany({})
					 
				}

				//np_posts
				if(_.size(np_posts) > 0 )
				{
					//delete 
					npdb.collection('np_posts').deleteMany({}) 
 
				}

				//np_terms
				if(_.size(np_terms) > 0 )
				{
					//delete 
					npdb.collection('np_terms').deleteMany({})
					 
				}
				 
				//np_comments
				if(_.size(np_comments) > 0 )
				{
					//delete 
					npdb.collection('np_comments').deleteMany({})
					 
				}
				//--->delete all old data > end


				//--->insert new data > start
				//delay for 1 seconds b/c it's too fast 
				//it needs to slow down to finish the last process				 

				setTimeout(function() 
				{	
					//np_users
					if(_.size(np_users) > 0 )
					{					 
						//insert
						npdb.collection('np_users').insertMany(np_users)
					}

					//np_options
					if(_.size(np_options) > 0 )
					{ 
						//insert
						npdb.collection('np_options').insertMany(np_options)
					}

					//np_posts
					if(_.size(np_posts) > 0 )
					{
						 

						//insert					
						npdb.collection('np_posts').insertMany(np_posts) 
					}

					//np_terms
					if(_.size(np_terms) > 0 )
					{
						 
						//insert
						npdb.collection('np_terms').insertMany(np_terms)
					}
					 
					//np_comments
					if(_.size(np_comments) > 0 )
					{
						 
						//insert
						npdb.collection('np_comments').insertMany(np_comments)
					}
					//--->insert new data > end

					setTimeout(function() 
					{
						//your code to be executed after 1 second
						//convert to numbers
						convert_field_to_number(
						{
							np_users:np_users,
							np_options:np_options,
							np_posts:np_posts,
							np_terms:np_terms,
							np_comments:np_comments,
						})

					}, delayMillis);

				}, delayMillis);

				

				



				

				


				res.json({status:'success', msg:'added new data' })
				return false

			} 

			///append
			if(import_type =='append')
			{
				//np_users
				if(_.size(np_users) > 0 )
				{ 
					//insert
					npdb.collection('np_users').insertMany(np_users)
				}

				//np_options
				if(_.size(np_options) > 0 )
				{ 
					//insert
					npdb.collection('np_options').insertMany(np_options)
				}

				//np_posts
				if(_.size(np_posts) > 0 )
				{ 
					//insert
					npdb.collection('np_posts').insertMany(np_posts)					
				}

				//np_terms
				if(_.size(np_terms) > 0 )
				{ 
					//insert
					npdb.collection('np_terms').insertMany(np_terms)
				}

				 
				//np_comments
				if(_.size(np_comments) > 0 )
				{
					 
					//insert
					npdb.collection('np_comments').insertMany(np_comments)
				}


				res.json({status:'success', msg:'appened data' })

				//convert to numbers
				convert_field_to_number(
				{
					np_users:np_users,
					np_options:np_options,
					np_posts:np_posts,
					np_terms:np_terms,
					np_comments:np_comments,
				})

				
				return false
			}


			return false
		}

		 

	})
		
 

});
//--->post data - end


var convert_field_to_number = function(obj)
{ 
	var np_users 		= obj.np_users
	var np_options 		= obj.np_options
	var np_posts 		= obj.np_posts
	var np_terms 		= obj.np_terms
	var np_comments 	= obj.np_comments

	//np_users
	if(_.size(np_users) > 0 )
	{	
		npdb.collection('np_users').find().forEach( function (x) 
		{   
			//convert to number
			x.user_id =  parseInt(x.user_id)  			 
			x.rec_dttm_unix =  parseInt(x.rec_dttm_unix) 
			npdb.collection('np_users').save(x)
		})
	}

	//np_options
	if(_.size(np_options) > 0 )
	{	
		npdb.collection('np_options').find().forEach( function (x) 
		{   
			//convert to number
			x.option_id =  parseInt(x.option_id)  
			x.rec_dttm_unix =  parseInt(x.rec_dttm_unix) 
			npdb.collection('np_options').save(x)
		})
	}

	//np_posts
	if(_.size(np_posts) > 0 )
	{	
		npdb.collection('np_posts').find().forEach( function (x) 
		{   
			//convert to number
				x.post_id =  parseInt(x.post_id)  
				x.post_author_id =  parseInt(x.post_author_id) 
				x.post_dttm_unix =  parseInt(x.post_dttm_unix) 

				//x.post_views =  parseInt(x.post_views)
				//set the views to zero 
				x.post_views =  parseInt(0) 
				x.comment_counter =  parseInt(x.comment_counter) 

				x.rec_dttm_unix =  parseInt(x.rec_dttm_unix) 
				x.comment_counter =  parseInt(x.comment_counter) 
				
				if(_.size(x.categories) > 0)
				{
					x.categories.forEach(function(y)
					{
						y.post_id =  parseInt(y.post_id) 
						y.term_id =  parseInt(y.term_id)  
					})
				}  
				npdb.collection('np_posts').save(x)
		})
		
	} 
	
	//np_terms
	if(_.size(np_terms) > 0 )
	{	
		npdb.collection('np_terms').find().forEach( function (x) 
		{   
			//convert to number
			x.term_id =  parseInt(x.term_id)  
			x.rec_dttm_unix =  parseInt(x.rec_dttm_unix) 
			npdb.collection('np_terms').save(x)
		})
	}

	//np_comments
	if(_.size(np_comments) > 0 )
	{	
		npdb.collection('np_comments').find().forEach( function (x) 
		{   
			//convert to number
			x.comment_id =  parseInt(x.comment_id)  
			x.post_id =  parseInt(x.post_id)  
			x.rec_dttm_unix =  parseInt(x.rec_dttm_unix) 
			npdb.collection('np_comments').save(x)
		})
	}

}
 