exports.get = function(req)
{
  /*
    This will get user ip address
    
    Note req has to be part of the call otherwise it won't work.
    
    call it like this: ip.get(req)


  */
  var ip_info = req.headers['x-forwarded-for'] || 
  req.connection.remoteAddress || 
  req.socket.remoteAddress ||
  req.connection.socket.remoteAddress;

  var array = ip_info.split(',');
  //
  var res = ip_info.replace("::ffff:", "");
  return res;
}


 